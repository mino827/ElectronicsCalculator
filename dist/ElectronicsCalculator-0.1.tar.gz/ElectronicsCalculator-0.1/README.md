# ElectronicsCalculator
 Python module that provides methods to perform common electronics calculations.

A sample test file (test.py) has been included in the Testing folder. It shows a sample use of the 
electronics_calculator module both with and without usage of the scale_factors module.
