# ElectronicsCalculator
Python module that provides many methods to perform common electronics calculations.

A sample test file (sample_test.py) has been included in the 'tests' folder. It shows a 
sample use of the electronics_calculator module both with and without usage of the 
scale_factors module.

We are happily accepting contributers to this project to assist in expanding it further.
